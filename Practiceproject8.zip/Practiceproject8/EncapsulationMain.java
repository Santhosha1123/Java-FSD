package Practiceproject8;

public class EncapsulationMain {
	public static void main (String[] args)  
    { 
        Encapsulation obj = new Encapsulation(); 
        obj.setName("Santhosha"); 
        obj.setAge(22); 
        obj.setRoll(13); 
        System.out.println("My name: " + obj.getName()); 
        System.out.println("My age: " + obj.getAge()); 
        System.out.println("My roll: " + obj.getRoll());      
    } 

}
