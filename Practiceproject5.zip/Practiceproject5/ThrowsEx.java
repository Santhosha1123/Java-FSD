package Practiceproject5;

public class ThrowsEx {
	void Division() throws Exception{
		int a=45,b=0,rs;
		rs=a/b;
		System.out.println("the result is:" +rs);
	}

	public static void main(String[] args) {
		ThrowsEx T = new ThrowsEx();
        try
       {
           T.Division();
       }
       catch(Exception Ex)
       {
           System.out.print("\n\tError : " + Ex.getMessage());
       }
       System.out.print("\n\tEnd of program.");

	}

}
