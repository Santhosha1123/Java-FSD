package practiceProject3;

public class CallByValue {
	int val=150;

	int operation(int val) {
		val =val*2/100;
		return(val);
	}

	public static void main(String args[]) {
		CallByValue  callByValueobj = new CallByValue();
		System.out.println("Before data is "+callByValueobj.val);
		callByValueobj.operation(100);
		System.out.println("After data is "+callByValueobj.val);

}
}
