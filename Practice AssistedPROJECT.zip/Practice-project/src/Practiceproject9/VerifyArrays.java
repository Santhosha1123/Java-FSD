package Practiceproject9;

public class VerifyArrays {

	public static void main(String[] args) {
		int[] array1 = {10, 20, 30,40,50};
        int[] array2 = {10, 20,40,50};
        boolean areEqual = true;

        if (array1.length != array2.length) {
            areEqual = false;
        } 
        else 
        {
            for (int i = 0; i < array1.length; i++)
            {
                if (array1[i] != array2[i])
                {
                    areEqual = false;
                    break;
                }
            }
        }

        if (areEqual) {
            System.out.println("The two arrays are equal.");
        } else {
            System.out.println("The two arrays are not equal.");
        }
	}

}
