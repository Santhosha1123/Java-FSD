package Practiceproject1;

public class TypeCasting {

	public static void main(String[] args) {
		//Implicit Casting
				int num=20;
				double decimal=num;
				System.out.println("Implicit casting:" + num +  "->" +decimal);
				
				//Explicit casting
				double decimal2=20.5;
				int num2=(int)decimal2;
				System.out.println("Explicit casting:" +decimal2  +"->" +num2);
			
	}

}
