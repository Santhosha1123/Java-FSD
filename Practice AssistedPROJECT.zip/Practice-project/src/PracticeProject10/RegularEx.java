package PracticeProject10;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularEx {

	public static void main(String[] args) {
		 String regex = "My Name is Santhosha";
	        String input = "I am Santhosha";

	        Pattern pattern = Pattern.compile(regex);
	        Matcher matcher = pattern.matcher(input);

	        if (matcher.matches())
	        {
	            System.out.println("The input string matches the regular expression.");
	        } 
	        else 
	        {
	            System.out.println("The input string does not match the regular expression.");
	        }
	}

}
