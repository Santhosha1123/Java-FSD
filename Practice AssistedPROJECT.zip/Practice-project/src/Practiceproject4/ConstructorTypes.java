package Practiceproject4;


public class ConstructorTypes {

	 private int id;
	 private String name;

	    // Default constructor
	    public ConstructorTypes() {
	    this.id = 0;
	    this.name = "Default";
	    }

	    // Parameterized constructor
	    public ConstructorTypes(int id, String name) {
	    this.id = id;
	    this.name = name;
	    }

	    // Copy constructor
	    public ConstructorTypes(ConstructorTypes ct) {
	    this.id = ct.id;
	    this.name = ct.name;
	    }

	    public static void main(String[] args) {
	        ConstructorTypes constructortype1 = new ConstructorTypes();
	        System.out.println("Default constructor: " + constructortype1.id + ", " + constructortype1.name);

	        ConstructorTypes constructortype2 = new ConstructorTypes(1, "Parameterized");
	        System.out.println("Parameterized constructor: " + constructortype2.id + ", " + constructortype2.name);

	        ConstructorTypes constructortype3 = new ConstructorTypes(constructortype2);
	        System.out.println("Copy constructor: " + constructortype3.id + ", " + constructortype3.name);
	    }
}
