package Practiceproject3;

public class ThreadedSend extends Thread {
	private String msg;
	private Thread t;
	Synchronisation synchronisation;
	ThreadedSend(String m, Synchronisation obj)
	{
		msg=m;
	synchronisation=obj;
		
	}
	public void run()
	{
		synchronized(synchronisation)
		{
			synchronisation.send(msg);
		}
	}
}


