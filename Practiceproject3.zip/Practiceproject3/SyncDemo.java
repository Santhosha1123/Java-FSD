package Practiceproject3;

public class SyncDemo {

	public static void main(String[] args) {
		Synchronisation synchronisationobj = new Synchronisation(); 
		ThreadedSend S1 = 
	            new ThreadedSend( " Hi " , synchronisationobj ); 
	        ThreadedSend S2 = 
	            new ThreadedSend( " Bye " , synchronisationobj ); 
	        S1.start(); 
	        S2.start(); 
	        try
	        { 
	            S1.join(); 
	            S2.join(); 
	        } 
	        catch(Exception e) 
	        { 
	            System.out.println("Interrupted"); 
	        } 
	    } 


	}


