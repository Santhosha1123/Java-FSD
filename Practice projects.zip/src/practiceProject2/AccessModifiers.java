package practiceProject2;

public class AccessModifiers {

		//default access modifier
				int num1;
			//private access modifier
				private int num2;
			//public access modifier
				public int num3;
			//protected access modifier
				protected int num4;
				
				//Main method
				public static void main(String[] args) {
					AccessModifiers AccessModifiersobj=new AccessModifiers();
					AccessModifiersobj.num1=10;
					AccessModifiersobj.num2=20;
					AccessModifiersobj.num3=30;
					AccessModifiersobj.num4=40;
					System.out.println("num1:" + AccessModifiersobj.num1);
					System.out.println("num2:" + AccessModifiersobj.num2);
					System.out.println("num3:" + AccessModifiersobj.num3);
					System.out.println("num4:" + AccessModifiersobj.num4);
	}

}
