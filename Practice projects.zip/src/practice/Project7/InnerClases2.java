package practice.Project7;

import practice.Project7.InnerClases.Inner;

public class InnerClases2 {

	private String msg="Inner Classes";

	void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println(msg);
	}

}
		 Inner l=new Inner();  
		 l.msg();  
		}  


		public static void main(String[] args) {
			InnerClases2  InnerClases2obj=new InnerClases2 ();  
			InnerClases2obj.display();  
			}
		}
//anonymous inner class
abstract class AnonymousInnerClass {
	   public abstract void display();
	}

		 
