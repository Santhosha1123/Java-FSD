package practice.Project7;

public class InnerClases {
	private String msg="Welcome to Java"; 
	 
	 class Inner{  
	  void hello(){System.out.println(msg+", Let us start learning Inner Classes");}  
	 }  


	public static void main(String[] args) {

		InnerClases InnerClasesobj=new InnerClases();
		InnerClases.Inner in=InnerClasesobj.new Inner();  
		in.hello();  
	}
}



 





	
